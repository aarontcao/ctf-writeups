<?php



require_once __DIR__ . '/../../lib/util.php';
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/db.php';

$ra = $_SERVER['REMOTE_ADDR'] ?? '';
$loopback = (bool) preg_match('/^(127\\.|::1$|0:0:0:0:0:0:0:1$)/', $ra);
if (!$loopback) {
    vk_json(['error' => 'keyring is bound to the appliance loopback interface', 'remote' => $ra], 403);
}




$mask = is_readable('/var/www/private/cap.mask')
      ? trim((string) @file_get_contents('/var/www/private/cap.mask')) : str_repeat("\0", 16);
$key  = vk_cap_key();
$masked = $key ^ substr(str_pad($mask, strlen($key), $mask), 0, strlen($key));
$sessions = [];
try {
    foreach (db()->query("SELECT id, session_id FROM jobs WHERE kind='restore' ORDER BY id DESC LIMIT 8")->fetchAll() as $r) {
        $sessions[] = ['id' => (int) $r['id'], 'session_id' => $r['session_id']];
    }
} catch (\Throwable $e) {}
vk_json([
    'cap_key_masked'   => base64_encode($masked),
    'restore_sessions' => $sessions,
    'alg'            => 'aes-128-gcm',
    'service'        => 'vk-keyring',
    'node'           => vk_config()['cluster_node'],
    'issued'         => vk_now(),
]);
