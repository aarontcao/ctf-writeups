<?php





require_once __DIR__ . '/../../lib/util.php';
require_once __DIR__ . '/../../lib/request.php';

if (vk_method() !== 'POST') vk_json(['error' => 'POST only'], 405);

$body     = vk_input();
$template = substr((string) ($body['template'] ?? ''), 0, 2000);
$event    = (string) ($body['event'] ?? 'restore.failed');

$mask = is_readable('/var/www/private/cap.mask')
      ? trim((string) @file_get_contents('/var/www/private/cap.mask')) : '';

$ctx = [
    'event' => $event, 'appliance' => 'vaultkeeper',
    'node' => getenv('VK_NODE') ?: 'node-a', 'job' => '#1042',
    'source' => 'nightly / full', 'status' => 'failed',
    'when' => gmdate('c'), 'workspace' => 'Acme Platform',
];
if (preg_match('/^maintenance\./', $event)) {
    $ctx['config'] = [
        'retention_days' => (int) (getenv('VK_RETENTION') ?: 30),
        'cluster_node'   => getenv('VK_NODE') ?: 'node-a',
        'cap_mask'       => $mask,
        'version'        => '4.2.1',
    ];
}

final class VkVal { public function __construct(public mixed $v, public bool $t = false) {} }

final class VkEval {
    private int $i = 0; private array $toks = []; private array $fns;
    public function __construct(private array $ctx, private array $secrets) {
        $this->fns = [
            'strlen' => fn($a) => strlen((string) $a[0]),
            'substr' => fn($a) => substr((string) $a[0], (int) $a[1], isset($a[2]) ? (int) $a[2] : null),
            'ord'    => fn($a) => ord((string) $a[0]),
            'chr'    => fn($a) => chr((int) $a[0]),
            'upper'  => fn($a) => strtoupper((string) $a[0]),
            'lower'  => fn($a) => strtolower((string) $a[0]),
            'int'    => fn($a) => (int) $a[0],
        ];
    }
    public function render(string $tpl): string {
        return preg_replace_callback('/\{\{(.*?)\}\}/s', function ($m) {
            $this->toks = $this->lex(trim($m[1])); $this->i = 0;
            $val = $this->parseCmp();
            if ($this->i < count($this->toks)) throw new RuntimeException('trailing tokens');
            if ($val->t) return '[redacted]';
            return is_scalar($val->v) ? (string) $val->v : json_encode($val->v);
        }, $tpl);
    }
    private function lex(string $s): array {
        $out = []; $n = strlen($s); $i = 0;
        while ($i < $n) {
            if (ctype_space($s[$i])) { $i++; continue; }
            if (preg_match('/\G\d+/', $s, $mm, 0, $i)) { $out[] = ['num', (int) $mm[0]]; $i += strlen($mm[0]); continue; }
            if (preg_match("/\G'((?:[^'\\\\]|\\\\.)*)'/", $s, $mm, 0, $i)) { $out[] = ['str', stripcslashes($mm[1])]; $i += strlen($mm[0]); continue; }
            if (preg_match('/\G[A-Za-z_][A-Za-z0-9_.]*/', $s, $mm, 0, $i)) { $out[] = ['id', $mm[0]]; $i += strlen($mm[0]); continue; }
            if (preg_match('/\G(==|!=|<=|>=|[()+\-*\/,<>])/', $s, $mm, 0, $i)) { $out[] = ['op', $mm[0]]; $i += strlen($mm[0]); continue; }
            throw new RuntimeException('bad char in expression');
        }
        return $out;
    }
    private function peek(): ?array { return $this->toks[$this->i] ?? null; }
    private function eat(string $op): void { $t = $this->peek(); if (!$t || $t[0] !== 'op' || $t[1] !== $op) throw new RuntimeException("expected $op"); $this->i++; }
    private function isOp(string $op): bool { $t = $this->peek(); return $t && $t[0] === 'op' && $t[1] === $op; }
    private function parseCmp(): VkVal {
        $l = $this->parseAdd();
        while (($t = $this->peek()) && $t[0] === 'op' && in_array($t[1], ['==','!=','<','>','<=','>='], true)) {
            $this->i++; $r = $this->parseAdd();
            $b = match ($t[1]) { '==' => $l->v == $r->v, '!=' => $l->v != $r->v, '<' => $l->v < $r->v, '>' => $l->v > $r->v, '<=' => $l->v <= $r->v, '>=' => $l->v >= $r->v };
            $l = new VkVal($b, $l->t || $r->t);
        }
        return $l;
    }
    private function parseAdd(): VkVal {
        $l = $this->parseMul();
        while (($t = $this->peek()) && $t[0] === 'op' && in_array($t[1], ['+','-'], true)) {
            $this->i++; $r = $this->parseMul(); $v = $t[1] === '+' ? $l->v + $r->v : $l->v - $r->v; $l = new VkVal($v, $l->t || $r->t);
        }
        return $l;
    }
    private function parseMul(): VkVal {
        $l = $this->parseUnary();
        while (($t = $this->peek()) && $t[0] === 'op' && in_array($t[1], ['*','/'], true)) {
            $this->i++; $r = $this->parseUnary();
            $v = $t[1] === '*' ? $l->v * $r->v : $l->v / $r->v;
            $l = new VkVal($v, $l->t || $r->t);
        }
        return $l;
    }
    private function parseUnary(): VkVal { if ($this->isOp('-')) { $this->i++; $x = $this->parseUnary(); return new VkVal(-$x->v, $x->t); } return $this->parsePrimary(); }
    private function parsePrimary(): VkVal {
        $t = $this->peek(); if (!$t) throw new RuntimeException('unexpected end');
        if ($t[0] === 'num') { $this->i++; return new VkVal($t[1], false); }
        if ($t[0] === 'str') { $this->i++; return new VkVal($t[1], false); }
        if ($t[0] === 'op' && $t[1] === '(') { $this->i++; $e = $this->parseCmp(); $this->eat(')'); return $e; }
        if ($t[0] === 'id') {
            $this->i++;
            if ($this->isOp('(')) {
                $name = $t[1];
                if (!isset($this->fns[$name])) throw new RuntimeException("unknown function: $name");
                $this->eat('('); $args = []; $tainted = false;
                if (!$this->isOp(')')) { do { $a = $this->parseCmp(); $args[] = $a->v; $tainted = $tainted || $a->t; } while ($this->isOp(',') && ($this->i++ === $this->i - 1)); }
                $this->eat(')');
                return new VkVal(($this->fns[$name])($args), $tainted);   
            }
            return $this->resolve($t[1]);
        }
        throw new RuntimeException('unexpected token');
    }
    private function resolve(string $path): VkVal {
        $v = $this->ctx;
        foreach (explode('.', $path) as $p) { if (is_array($v) && array_key_exists($p, $v)) $v = $v[$p]; else return new VkVal('', false); }
        if (!is_scalar($v)) {
            $j = (string) json_encode($v);
            $tainted = false;
            foreach ($this->secrets as $s) { if ($s !== '' && strpos($j, (string) $s) !== false) { $tainted = true; break; } }
            return new VkVal($j, $tainted);
        }
        return new VkVal($v, in_array((string) $v, $this->secrets, true));
    }
}

$secrets = array_values(array_filter([$mask], 'strlen'));
try {
    $rendered = (new VkEval($ctx, $secrets))->render($template);
    
    foreach ($secrets as $s) { if ($s !== '') $rendered = str_replace((string) $s, '[redacted]', (string) $rendered); }
} catch (\Throwable $e) {
    
    vk_json(['event' => $event, 'ok' => false, 'error' => 'render error'], 500);
}
vk_json(['event' => $event, 'ok' => true, 'rendered' => $rendered, 'tokens' => array_keys($ctx)]);
