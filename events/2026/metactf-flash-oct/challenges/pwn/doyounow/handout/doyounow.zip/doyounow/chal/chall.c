#define _GNU_SOURCE
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_NOTES 0x20

char num[0x8];
uint COUNTER = 0x0;
struct notes {
  char *chunk;
  uint size;

} typedef notes;

unsigned long read_num() {
  puts(">>");
  read(STDIN_FILENO, num, 0x4);
  return atoll(num);
}

void menu() {
  puts("1.add_notes");
  puts("2.delete_notes");
  puts("3.edit_notes");
  puts("4.show_notes");
  puts("5.forge_notes");
}

struct notes Notes[MAX_NOTES];

void forge_notes(notes *Notes) {
  // garbage value
  if (COUNTER) {
    puts("Begone begone begone");
    exit(0x0);
  }
  FILE *fp;
  fp = fopen("/dev/urandom", "r");
  char data[0x90];
  fread(&data, 1, 0x90, fp);
  fclose(fp);

  puts("Enter index");
  unsigned long long index = read_num();
  memcpy(Notes[index].chunk, data, strlen(data));
  uint *heap = malloc(0x20 * sizeof(int));
  for (uint i = 0x0; i < 0x20; i++) {
    heap[i] = Notes[index].size;
  }
  Notes[MAX_NOTES].size = 0x20 * sizeof(int);
  COUNTER++;
}

void show_notes(notes *Notes) {
  unsigned index = read_num();
  puts("Nanja koriya!!!");
  puts(Notes[index].chunk);
}

void add_notes() {
  puts("Index:");
  unsigned long index = read_num();
  puts("Size:");
  unsigned long size = read_num();
  void *malloced = malloc(size);
  Notes[index].chunk = (char *)malloced;
  Notes[index].size = size;
  puts("added!");
}

void delete_notes() {
  puts("Index:");
  unsigned long index = read_num();
  free(Notes[index].chunk);
  Notes[index].chunk = 0x0;
  Notes[index].size = 0x0;

  puts("deleted!");
}

void edit_notes() {
  puts("Index");
  unsigned long index = read_num();
  read(STDIN_FILENO, Notes[index].chunk, Notes[index].size);
  puts("edited!");
}

int main() {

  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  while (true) {
    menu();
    unsigned long index = read_num();

    if (index == 0x1)
      add_notes();
    if (index == 0x2)
      delete_notes();

    if (index == 0x3)
      edit_notes();

    if (index == 0x4)
      show_notes(Notes);

    if (index == 0x5)
      forge_notes(Notes);

    if (index == 0x6)

      return 0;
  }
}
