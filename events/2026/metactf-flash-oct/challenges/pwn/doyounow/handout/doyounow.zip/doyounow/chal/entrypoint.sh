#!/bin/sh
set -eu

FLAG="${FLAG-}"
if [ -z "$FLAG" ]; then
  FLAG='SkillBit{Fake_Flag_For_Testing}'
fi

printf '%s\n' "$FLAG" > /app/flag.txt
chmod 644 /app/flag.txt
unset FLAG

exec socat TCP-LISTEN:8080,reuseaddr,fork EXEC:/app/challenge,stderr
