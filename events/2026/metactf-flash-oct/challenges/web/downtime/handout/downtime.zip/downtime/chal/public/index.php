<?php
/* Down for maintenance. */
http_response_code(503);
header('Retry-After: 3600');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Down for maintenance</title>
<style>
  body {
    margin: 0;
    padding: 2.75rem 1.25rem;
    background: #ffffff;
    color: #1b1b1b;
    font: 16px/1.6 -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  }
  .wrap { max-width: 37rem; margin: 0 auto; }
  h1 { margin: 0 0 1rem; font-size: 1.35rem; font-weight: 600; }
  hr { border: 0; border-top: 1px solid #dcdcdc; margin: 0 0 1.5rem; }
  p { margin: 0 0 1rem; }
  .small { margin-top: 1.75rem; font-size: .82rem; color: #666; }
</style>
</head>
<body>
  <div class="wrap">
    <h1>Down for maintenance</h1>
    <hr>
    <p>We will be back up soon.</p>
    <p class="small">Powered by PHP <?= htmlspecialchars(PHP_VERSION) ?></p>
  </div>
</body>
</html>